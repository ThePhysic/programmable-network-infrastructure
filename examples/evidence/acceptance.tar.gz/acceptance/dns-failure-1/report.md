# Network experiment report

Experiment: `fba39d00ff844970826875dd55e02ff9`  
Scenario: `dns-failure`  
Started: 2026-11-02T04:18:52.742879+00:00

## Observed outcome

Name resolution failed while application operations failed; a DNS failure is supported by resolver evidence. A gateway-origin direct-IP control succeeded along the gateway-to-backend route, supporting a name-versus-transport distinction. This control bypasses DNS and proxy forwarding and does not verify the client-to-proxy hop.

Evidence confidence: **supported**. Restoration: **verified**. Teardown verified: **yes**.

Experiment acceptance: **passed**. Scenario verification: **verified**.

## Workload and environment

```json
{
  "environment": {
    "cpu_model": "AMD Ryzen 9 7940HS w/ Radeon 780M Graphics",
    "doctor": {
      "binary": "/opt/netlab-public/programmable-network-infrastructure/bin/netlab-agent",
      "binary_exists": true,
      "environment": {
        "cpu_count": 16,
        "kernel": "6.18.54.1-microsoft-standard-WSL2",
        "platform": "Linux-6.18.54.1-microsoft-standard-WSL2-x86_64-with-glibc2.39",
        "python": "3.12.3"
      },
      "frr_vty_group_member": true,
      "linux": true,
      "ready": true,
      "root": true,
      "tools": {
        "bgpd": "/usr/lib/frr/bgpd",
        "ip": "/usr/sbin/ip",
        "nft": "/usr/sbin/nft",
        "python3": "/usr/bin/python3",
        "ss": "/usr/bin/ss",
        "tc": "/usr/sbin/tc",
        "tcpdump": "/usr/bin/tcpdump",
        "vtysh": "/usr/bin/vtysh",
        "zebra": "/usr/lib/frr/zebra"
      }
    },
    "frr_version": null,
    "go_binary_version": "/opt/netlab-public/programmable-network-infrastructure/bin/netlab-agent: go1.22.2",
    "iproute_version": "ip utility, iproute2-6.1.0, libbpf 1.3.0",
    "kernel": "6.18.54.1-microsoft-standard-WSL2",
    "logical_cpus": 16,
    "memory_total": "MemTotal:       15970204 kB",
    "netlab_version": "0.1.0",
    "nft_version": "nftables v1.0.9 (Old Doc Yak #3)",
    "platform": "Linux-6.18.54.1-microsoft-standard-WSL2-x86_64-with-glibc2.39",
    "python": "3.12.3"
  },
  "topology": {
    "alternate_path": [
      "gateway",
      "r1",
      "r3",
      "r2",
      "backend"
    ],
    "backend": "10.77.3.2:19090",
    "dns": "10.77.1.1:53",
    "gateway": "10.77.1.1:18080",
    "id": "six-node-bgp-diamond",
    "links": [
      {
        "left": "client",
        "left_address": "10.77.1.2/24",
        "left_interface": "eth0",
        "right": "gateway",
        "right_address": "10.77.1.1/24",
        "right_interface": "client0"
      },
      {
        "left": "gateway",
        "left_address": "10.77.2.2/24",
        "left_interface": "uplink0",
        "right": "r1",
        "right_address": "10.77.2.1/24",
        "right_interface": "gateway0"
      },
      {
        "left": "r1",
        "left_address": "10.77.12.1/24",
        "left_interface": "direct0",
        "right": "r2",
        "right_address": "10.77.12.2/24",
        "right_interface": "direct0"
      },
      {
        "left": "r1",
        "left_address": "10.77.13.1/24",
        "left_interface": "backup0",
        "right": "r3",
        "right_address": "10.77.13.3/24",
        "right_interface": "left0"
      },
      {
        "left": "r3",
        "left_address": "10.77.23.3/24",
        "left_interface": "right0",
        "right": "r2",
        "right_address": "10.77.23.2/24",
        "right_interface": "backup0"
      },
      {
        "left": "r2",
        "left_address": "10.77.3.1/24",
        "left_interface": "service0",
        "right": "backend",
        "right_address": "10.77.3.2/24",
        "right_interface": "eth0"
      }
    ],
    "namespace_prefix": "pnid-fa2106e5aa",
    "nodes": [
      "client",
      "gateway",
      "r1",
      "r2",
      "r3",
      "backend"
    ],
    "primary_path": [
      "gateway",
      "r1",
      "r2",
      "backend"
    ]
  },
  "workload": {
    "concurrency": 2,
    "connection_model": "one TCP connection per verified echo",
    "duration_seconds": 2.0,
    "payload_bytes": 256,
    "rate_per_second": 20.0
  }
}
```

## Measurements

Latency percentiles describe successful complete byte-verified operations. Failure counts have a separate denominator.

| Phase | Attempts | Successes | Errors | Success fraction | Duration (s) | Attempts/s | p50 (ms) | p95 (ms) | p99 (ms) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| baseline | 40 | 40 | 0 | 1.000 | 1.954 | 20.474 | 2.430 | 3.680 | 5.241 |
| fault | 40 | 0 | 40 | 0.000 | 1.952 | 20.496 | unmeasured | unmeasured | unmeasured |
| recovery | 40 | 40 | 0 | 1.000 | 1.954 | 20.473 | 2.486 | 3.823 | 4.993 |

### Recovery clocks

| Measurement | Seconds | Definition | Evidence |
|---|---:|---|---|
| fault_to_detection_seconds | 0.150 | Conservative upper bound from beginning fault application to first failed sampled echo completion; includes sampling gaps, timeout, and all parent/child launch/return overhead. | [artifact](<events.json>), [artifact](<fault/probe.json>), [artifact](<fault/probe-window.json>) |
| route_convergence_seconds | unmeasured | Routing change to a defined observed converged route state. | not linked |
| first_success_after_restoration_seconds | 0.233 | Conservative upper bound from restoration start to first successful sampled echo; includes restoration, sampling gaps, and all parent/child launch/return overhead. Earlier success may be unobserved. | [artifact](<events.json>), [artifact](<recovery/probe.json>), [artifact](<recovery/probe-window.json>) |
| stable_recovery_seconds | 2.185 | Completion of the error-free post-restoration probe window (at least one second); independent state recovery is evaluated separately. This is a sampled bound, not continuous health assurance. | [artifact](<events.json>), [artifact](<recovery/probe.json>), [artifact](<recovery/probe-window.json>), [artifact](<recovery/snapshot/snapshot.json>) |

## Evidence and interpretation

Injected-fault information is experiment ground truth. Interpretation is derived independently from these observations.

| Observation | Value | Primary evidence |
|---|---|---|
| baseline.backend_route_present | yes | [artifact](<baseline/snapshot/r1-routes.json>) |
| baseline.bgp_backend_prefix_present | yes | [artifact](<baseline/snapshot/r1-bgp-routes.json>) |
| baseline.bgp_peers_established | yes | [artifact](<baseline/snapshot/r1-bgp-summary.json>), [artifact](<baseline/snapshot/r2-bgp-summary.json>), [artifact](<baseline/snapshot/r3-bgp-summary.json>) |
| baseline.backend_prefix_denied | no | [artifact](<baseline/snapshot/r1-running-config.txt>), [artifact](<baseline/snapshot/r1-prefix-lists.txt>) |
| baseline.backend_prefix_policy_present | no | [artifact](<baseline/snapshot/r1-running-config.txt>), [artifact](<baseline/snapshot/r1-prefix-lists.txt>) |
| baseline.backend_prefix_policy | {"decision": null, "display_decision": null, "inbound_neighbors": [], "sources_consistent": true} | [artifact](<baseline/snapshot/r1-running-config.txt>), [artifact](<baseline/snapshot/r1-prefix-lists.txt>) |
| baseline.backend_listener_present | yes | [artifact](<baseline/snapshot/backend-sockets.txt>) |
| baseline.dns_ok | yes | [artifact](<baseline/snapshot/gateway-dns.json>) |
| baseline.primary_link_up | yes | [artifact](<baseline/snapshot/r1-links.json>) |
| baseline.netem_active | no | [artifact](<baseline/snapshot/gateway-netem.json>) |
| baseline.firewall_drop_active | no | [artifact](<baseline/snapshot/backend-firewall.json>) |
| baseline.firewall_drop_packets | 0 | [artifact](<baseline/snapshot/backend-firewall.json>) |
| baseline.backend_route_nexthop | 10.77.12.2 | [artifact](<baseline/snapshot/r1-routes.json>) |
| baseline.dns_result | {"address": "10.77.3.2", "name": "backend.lab", "ok": true, "rcode": 0} | not linked |
| baseline.gateway_metrics | {"accepted": 40, "accepted_definition": "all accepted TCP sockets including sockets immediately rejected at the connection limit", "active_connections": 0, "bytes_down": 10240, "bytes_up": 10240, "cpu_boundary": "cumulative CPU seconds for the entire process", "cpu_measurement_available": true, "cpu_system_seconds": 0.083724, "cpu_total_seconds": 0.11721300000000001, "cpu_user_seconds": 0.033489, "errors": {}, "errors_definition": "one terminal failure class per admitted session; connection-limit rejections are counted separately", "file_descriptors": 10, "gc_cycles": 1, "goroutines": 8, "heap_alloc_bytes": 717712, "heap_sys_bytes": 7634944, "log_dropped_total": 0, "log_policy": "64 queued records plus at most one sink write; overflow is dropped; one blocked sink goroutine may remain until release or process exit", "log_queue_capacity": 64, "log_queue_length": 0, "log_shutdown_timed_out": false, "log_sink_inflight": false, "log_write_errors_total": 0, "log_written_total": 40, "max_connections": 16, "rejected": 0, "rss_bytes": 8810496, "uptime_seconds": 5.194978644} | [artifact](<baseline/snapshot/gateway-metrics.json>) |
| baseline.probe | {"all_successful": true, "attempts": 40, "attempts_per_second": 20.473618761539417, "direct_probe": {"all_successful": true, "attempts": 10, "attempts_per_second": 11.03120632297274, "duration_seconds": 0.90651917, "errors": {}, "failures": 0, "latency_ms": {"p50": 0.775398, "p95": 1.057778, "p99": 1.057778}, "samples_truncated": false, "success_rate": 1.0, "successes": 10, "successful_bytes": 2560, "valid": true}, "duration_seconds": 1.953733752, "errors": {}, "failures": 0, "latency_ms": {"p50": 2.430086, "p95": 3.679801, "p99": 5.240648}, "samples_truncated": false, "success_rate": 1.0, "successes": 40, "successful_bytes": 10240, "valid": true} | [artifact](<baseline/probe.json>), [artifact](<baseline/direct-probe.json>) |
| baseline.direct_probe | {"all_successful": true, "attempts": 10, "attempts_per_second": 11.03120632297274, "duration_seconds": 0.90651917, "errors": {}, "failures": 0, "latency_ms": {"p50": 0.775398, "p95": 1.057778, "p99": 1.057778}, "samples_truncated": false, "success_rate": 1.0, "successes": 10, "successful_bytes": 2560, "valid": true} | [artifact](<baseline/direct-probe.json>) |
| fault.backend_route_present | yes | [artifact](<fault/snapshot/r1-routes.json>) |
| fault.bgp_backend_prefix_present | yes | [artifact](<fault/snapshot/r1-bgp-routes.json>) |
| fault.bgp_peers_established | yes | [artifact](<fault/snapshot/r1-bgp-summary.json>), [artifact](<fault/snapshot/r2-bgp-summary.json>), [artifact](<fault/snapshot/r3-bgp-summary.json>) |
| fault.backend_prefix_denied | no | [artifact](<fault/snapshot/r1-running-config.txt>), [artifact](<fault/snapshot/r1-prefix-lists.txt>) |
| fault.backend_prefix_policy_present | no | [artifact](<fault/snapshot/r1-running-config.txt>), [artifact](<fault/snapshot/r1-prefix-lists.txt>) |
| fault.backend_prefix_policy | {"decision": null, "display_decision": null, "inbound_neighbors": [], "sources_consistent": true} | [artifact](<fault/snapshot/r1-running-config.txt>), [artifact](<fault/snapshot/r1-prefix-lists.txt>) |
| fault.backend_listener_present | yes | [artifact](<fault/snapshot/backend-sockets.txt>) |
| fault.dns_ok | no | [artifact](<fault/snapshot/gateway-dns.json>) |
| fault.primary_link_up | yes | [artifact](<fault/snapshot/r1-links.json>) |
| fault.netem_active | no | [artifact](<fault/snapshot/gateway-netem.json>) |
| fault.firewall_drop_active | no | [artifact](<fault/snapshot/backend-firewall.json>) |
| fault.firewall_drop_packets | 0 | [artifact](<fault/snapshot/backend-firewall.json>) |
| fault.backend_route_nexthop | 10.77.12.2 | [artifact](<fault/snapshot/r1-routes.json>) |
| fault.dns_result | {"address": null, "name": "backend.lab", "ok": false, "rcode": 3} | not linked |
| fault.gateway_metrics | {"accepted": 80, "accepted_definition": "all accepted TCP sockets including sockets immediately rejected at the connection limit", "active_connections": 0, "bytes_down": 10240, "bytes_up": 10240, "cpu_boundary": "cumulative CPU seconds for the entire process", "cpu_measurement_available": true, "cpu_system_seconds": 0.109279, "cpu_total_seconds": 0.18031, "cpu_user_seconds": 0.071031, "errors": {"upstream_dns_error": 40}, "errors_definition": "one terminal failure class per admitted session; connection-limit rejections are counted separately", "file_descriptors": 10, "gc_cycles": 1, "goroutines": 8, "heap_alloc_bytes": 1182592, "heap_sys_bytes": 7634944, "log_dropped_total": 0, "log_policy": "64 queued records plus at most one sink write; overflow is dropped; one blocked sink goroutine may remain until release or process exit", "log_queue_capacity": 64, "log_queue_length": 0, "log_shutdown_timed_out": false, "log_sink_inflight": false, "log_write_errors_total": 0, "log_written_total": 80, "max_connections": 16, "rejected": 0, "rss_bytes": 9039872, "uptime_seconds": 9.972209611} | [artifact](<fault/snapshot/gateway-metrics.json>) |
| fault.probe | {"all_successful": false, "attempts": 40, "attempts_per_second": 20.49648403722755, "direct_probe": {"all_successful": true, "attempts": 10, "attempts_per_second": 11.09283378167406, "duration_seconds": 0.901482903, "errors": {}, "failures": 0, "latency_ms": {"p50": 0.913966, "p95": 1.059722, "p99": 1.059722}, "samples_truncated": false, "success_rate": 1.0, "successes": 10, "successful_bytes": 2560, "valid": true}, "duration_seconds": 1.9515542240000001, "errors": {"reset": 40}, "failures": 40, "latency_ms": {"p50": null, "p95": null, "p99": null}, "samples_truncated": false, "success_rate": 0.0, "successes": 0, "successful_bytes": 0, "valid": true} | [artifact](<fault/probe.json>), [artifact](<fault/direct-probe.json>) |
| fault.direct_probe | {"all_successful": true, "attempts": 10, "attempts_per_second": 11.09283378167406, "duration_seconds": 0.901482903, "errors": {}, "failures": 0, "latency_ms": {"p50": 0.913966, "p95": 1.059722, "p99": 1.059722}, "samples_truncated": false, "success_rate": 1.0, "successes": 10, "successful_bytes": 2560, "valid": true} | [artifact](<fault/direct-probe.json>) |
| recovery.backend_route_present | yes | [artifact](<recovery/snapshot/r1-routes.json>) |
| recovery.bgp_backend_prefix_present | yes | [artifact](<recovery/snapshot/r1-bgp-routes.json>) |
| recovery.bgp_peers_established | yes | [artifact](<recovery/snapshot/r1-bgp-summary.json>), [artifact](<recovery/snapshot/r2-bgp-summary.json>), [artifact](<recovery/snapshot/r3-bgp-summary.json>) |
| recovery.backend_prefix_denied | no | [artifact](<recovery/snapshot/r1-running-config.txt>), [artifact](<recovery/snapshot/r1-prefix-lists.txt>) |
| recovery.backend_prefix_policy_present | no | [artifact](<recovery/snapshot/r1-running-config.txt>), [artifact](<recovery/snapshot/r1-prefix-lists.txt>) |
| recovery.backend_prefix_policy | {"decision": null, "display_decision": null, "inbound_neighbors": [], "sources_consistent": true} | [artifact](<recovery/snapshot/r1-running-config.txt>), [artifact](<recovery/snapshot/r1-prefix-lists.txt>) |
| recovery.backend_listener_present | yes | [artifact](<recovery/snapshot/backend-sockets.txt>) |
| recovery.dns_ok | yes | [artifact](<recovery/snapshot/gateway-dns.json>) |
| recovery.primary_link_up | yes | [artifact](<recovery/snapshot/r1-links.json>) |
| recovery.netem_active | no | [artifact](<recovery/snapshot/gateway-netem.json>) |
| recovery.firewall_drop_active | no | [artifact](<recovery/snapshot/backend-firewall.json>) |
| recovery.firewall_drop_packets | 0 | [artifact](<recovery/snapshot/backend-firewall.json>) |
| recovery.backend_route_nexthop | 10.77.12.2 | [artifact](<recovery/snapshot/r1-routes.json>) |
| recovery.dns_result | {"address": "10.77.3.2", "name": "backend.lab", "ok": true, "rcode": 0} | not linked |
| recovery.gateway_metrics | {"accepted": 120, "accepted_definition": "all accepted TCP sockets including sockets immediately rejected at the connection limit", "active_connections": 0, "bytes_down": 20480, "bytes_up": 20480, "cpu_boundary": "cumulative CPU seconds for the entire process", "cpu_measurement_available": true, "cpu_system_seconds": 0.18756, "cpu_total_seconds": 0.28134000000000003, "cpu_user_seconds": 0.09378, "errors": {"upstream_dns_error": 40}, "errors_definition": "one terminal failure class per admitted session; connection-limit rejections are counted separately", "file_descriptors": 10, "gc_cycles": 2, "goroutines": 8, "heap_alloc_bytes": 1150784, "heap_sys_bytes": 7634944, "log_dropped_total": 0, "log_policy": "64 queued records plus at most one sink write; overflow is dropped; one blocked sink goroutine may remain until release or process exit", "log_queue_capacity": 64, "log_queue_length": 0, "log_shutdown_timed_out": false, "log_sink_inflight": false, "log_write_errors_total": 0, "log_written_total": 120, "max_connections": 16, "rejected": 0, "rss_bytes": 10010624, "uptime_seconds": 14.8510167} | [artifact](<recovery/snapshot/gateway-metrics.json>) |
| recovery.probe | {"all_successful": true, "attempts": 40, "attempts_per_second": 20.473321606422864, "direct_probe": {"all_successful": true, "attempts": 10, "attempts_per_second": 11.072453448396763, "duration_seconds": 0.903142203, "errors": {}, "failures": 0, "latency_ms": {"p50": 0.992091, "p95": 1.192667, "p99": 1.192667}, "samples_truncated": false, "success_rate": 1.0, "successes": 10, "successful_bytes": 2560, "valid": true}, "duration_seconds": 1.953762109, "errors": {}, "failures": 0, "latency_ms": {"p50": 2.485809, "p95": 3.822614, "p99": 4.992967}, "samples_truncated": false, "success_rate": 1.0, "successes": 40, "successful_bytes": 10240, "valid": true} | [artifact](<recovery/probe.json>), [artifact](<recovery/direct-probe.json>) |
| recovery.direct_probe | {"all_successful": true, "attempts": 10, "attempts_per_second": 11.072453448396763, "duration_seconds": 0.903142203, "errors": {}, "failures": 0, "latency_ms": {"p50": 0.992091, "p95": 1.192667, "p99": 1.192667}, "samples_truncated": false, "success_rate": 1.0, "successes": 10, "successful_bytes": 2560, "valid": true} | [artifact](<recovery/direct-probe.json>) |

Supporting observations: `baseline.dns_ok`, `fault.dns_ok`, `fault.probe`, `fault.direct_probe`.

## Restoration checks

| Check | Outcome |
|---|---|
| baseline_payload_transfer | verified |
| recovery_payload_transfer | verified |
| backend_route_present | verified |
| backend_listener_present | verified |
| dns_ok | verified |
| primary_link_up | verified |
| netem_active | verified |
| bgp_peers_established | verified |
| bgp_backend_prefix_present | verified |
| firewall_drop_active | verified |
| backend_prefix_denied | verified |
| backend_prefix_policy_present | verified |
| backend_route_nexthop | verified |

## Scenario acceptance

These checks are recomputed from the current observations and describe whether the intended experiment effect was observed; they are separate from the independently recomputed diagnosis.

| Check | Outcome |
|---|---|
| resolution_failed | verified |
| application_disrupted | verified |
| route_still_present | verified |
| direct_ip_control_succeeds | verified |

## Event timeline

| Sequence | Event | Local elapsed (s) | Wall time |
|---:|---|---:|---|
| 1 | startup-started | 1.230 | 2026-11-02T04:18:53.972967+00:00 |
| 2 | startup-finished | 5.018 | 2026-11-02T04:18:57.760303+00:00 |
| 3 | baseline-started | 5.038 | 2026-11-02T04:18:57.781272+00:00 |
| 4 | baseline-finished | 10.095 | 2026-11-02T04:19:02.837354+00:00 |
| 5 | fault-application-started | 10.115 | 2026-11-02T04:19:02.857672+00:00 |
| 6 | fault-applied | 10.133 | 2026-11-02T04:19:02.875417+00:00 |
| 7 | fault-started | 10.153 | 2026-11-02T04:19:02.895878+00:00 |
| 8 | fault-finished | 14.837 | 2026-11-02T04:19:06.208404+00:00 |
| 9 | restoration-started | 14.849 | 2026-11-02T04:19:06.219757+00:00 |
| 10 | restoration-finished | 14.975 | 2026-11-02T04:19:06.346581+00:00 |
| 11 | recovery-started | 14.995 | 2026-11-02T04:19:06.366112+00:00 |
| 12 | recovery-finished | 19.746 | 2026-11-02T04:19:11.117216+00:00 |
| 13 | cleanup-started | 19.761 | 2026-11-02T04:19:11.132477+00:00 |
| 14 | cleanup-finished | 21.079 | 2026-11-02T04:19:12.449906+00:00 |

## Injected change

```json
{
  "applied_at": "2026-11-02T04:19:02.874189+00:00",
  "apply_seconds": 0.00033130899987554585,
  "kind": "dns-failure",
  "status": "applied"
}
```

## Limitations

- baseline: fewer than 100 operations; tail percentiles have limited resolution.
- fault: fewer than 100 operations; tail percentiles have limited resolution.
- recovery: fewer than 100 operations; tail percentiles have limited resolution.
- route_convergence_seconds was not independently measured; phase snapshots do not establish this timing.
- Evidence is sampled within one host's local time context; cross-source timestamps do not imply perfect global synchronization.

Primary artifacts and checksums are listed in the experiment manifest. A configured route or disabled injector alone does not prove service recovery.
