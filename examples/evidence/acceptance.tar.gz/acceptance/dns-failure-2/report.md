# Network experiment report

Experiment: `2a04f508b06d4977a7135c78f801f303`  
Scenario: `dns-failure`  
Started: 2026-11-02T04:21:55.133321+00:00

## Observed outcome

Name resolution failed while application operations failed; a DNS failure is supported by resolver evidence. A gateway-origin direct-IP control succeeded along the gateway-to-backend route, supporting a name-versus-transport distinction. This control bypasses DNS and proxy forwarding and does not verify the client-to-proxy hop.

Evidence confidence: **supported**. Restoration: **verified**. Teardown verified: **yes**.

Experiment acceptance: **passed**. Scenario verification: **verified**.

## Workload and environment

```json
{
  "environment": {
    "cpu_model": "AMD Ryzen 9 7940HS w/ Radeon 780M Graphics",
    "doctor": {
      "binary": "/opt/netlab-public/programmable-network-infrastructure/bin/netlab-agent",
      "binary_exists": true,
      "environment": {
        "cpu_count": 16,
        "kernel": "6.18.54.1-microsoft-standard-WSL2",
        "platform": "Linux-6.18.54.1-microsoft-standard-WSL2-x86_64-with-glibc2.39",
        "python": "3.12.3"
      },
      "frr_vty_group_member": true,
      "linux": true,
      "ready": true,
      "root": true,
      "tools": {
        "bgpd": "/usr/lib/frr/bgpd",
        "ip": "/usr/sbin/ip",
        "nft": "/usr/sbin/nft",
        "python3": "/usr/bin/python3",
        "ss": "/usr/bin/ss",
        "tc": "/usr/sbin/tc",
        "tcpdump": "/usr/bin/tcpdump",
        "vtysh": "/usr/bin/vtysh",
        "zebra": "/usr/lib/frr/zebra"
      }
    },
    "frr_version": null,
    "go_binary_version": "/opt/netlab-public/programmable-network-infrastructure/bin/netlab-agent: go1.22.2",
    "iproute_version": "ip utility, iproute2-6.1.0, libbpf 1.3.0",
    "kernel": "6.18.54.1-microsoft-standard-WSL2",
    "logical_cpus": 16,
    "memory_total": "MemTotal:       15970204 kB",
    "netlab_version": "0.1.0",
    "nft_version": "nftables v1.0.9 (Old Doc Yak #3)",
    "platform": "Linux-6.18.54.1-microsoft-standard-WSL2-x86_64-with-glibc2.39",
    "python": "3.12.3"
  },
  "topology": {
    "alternate_path": [
      "gateway",
      "r1",
      "r3",
      "r2",
      "backend"
    ],
    "backend": "10.77.3.2:19090",
    "dns": "10.77.1.1:53",
    "gateway": "10.77.1.1:18080",
    "id": "six-node-bgp-diamond",
    "links": [
      {
        "left": "client",
        "left_address": "10.77.1.2/24",
        "left_interface": "eth0",
        "right": "gateway",
        "right_address": "10.77.1.1/24",
        "right_interface": "client0"
      },
      {
        "left": "gateway",
        "left_address": "10.77.2.2/24",
        "left_interface": "uplink0",
        "right": "r1",
        "right_address": "10.77.2.1/24",
        "right_interface": "gateway0"
      },
      {
        "left": "r1",
        "left_address": "10.77.12.1/24",
        "left_interface": "direct0",
        "right": "r2",
        "right_address": "10.77.12.2/24",
        "right_interface": "direct0"
      },
      {
        "left": "r1",
        "left_address": "10.77.13.1/24",
        "left_interface": "backup0",
        "right": "r3",
        "right_address": "10.77.13.3/24",
        "right_interface": "left0"
      },
      {
        "left": "r3",
        "left_address": "10.77.23.3/24",
        "left_interface": "right0",
        "right": "r2",
        "right_address": "10.77.23.2/24",
        "right_interface": "backup0"
      },
      {
        "left": "r2",
        "left_address": "10.77.3.1/24",
        "left_interface": "service0",
        "right": "backend",
        "right_address": "10.77.3.2/24",
        "right_interface": "eth0"
      }
    ],
    "namespace_prefix": "pnid-fa2106e5aa",
    "nodes": [
      "client",
      "gateway",
      "r1",
      "r2",
      "r3",
      "backend"
    ],
    "primary_path": [
      "gateway",
      "r1",
      "r2",
      "backend"
    ]
  },
  "workload": {
    "concurrency": 2,
    "connection_model": "one TCP connection per verified echo",
    "duration_seconds": 2.0,
    "payload_bytes": 256,
    "rate_per_second": 20.0
  }
}
```

## Measurements

Latency percentiles describe successful complete byte-verified operations. Failure counts have a separate denominator.

| Phase | Attempts | Successes | Errors | Success fraction | Duration (s) | Attempts/s | p50 (ms) | p95 (ms) | p99 (ms) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| baseline | 40 | 40 | 0 | 1.000 | 1.955 | 20.462 | 2.381 | 3.426 | 6.112 |
| fault | 40 | 0 | 40 | 0.000 | 1.953 | 20.483 | unmeasured | unmeasured | unmeasured |
| recovery | 40 | 40 | 0 | 1.000 | 1.954 | 20.469 | 2.562 | 3.407 | 5.236 |

### Recovery clocks

| Measurement | Seconds | Definition | Evidence |
|---|---:|---|---|
| fault_to_detection_seconds | 0.105 | Conservative upper bound from beginning fault application to first failed sampled echo completion; includes sampling gaps, timeout, and all parent/child launch/return overhead. | [artifact](<events.json>), [artifact](<fault/probe.json>), [artifact](<fault/probe-window.json>) |
| route_convergence_seconds | unmeasured | Routing change to a defined observed converged route state. | not linked |
| first_success_after_restoration_seconds | 0.201 | Conservative upper bound from restoration start to first successful sampled echo; includes restoration, sampling gaps, and all parent/child launch/return overhead. Earlier success may be unobserved. | [artifact](<events.json>), [artifact](<recovery/probe.json>), [artifact](<recovery/probe-window.json>) |
| stable_recovery_seconds | 2.154 | Completion of the error-free post-restoration probe window (at least one second); independent state recovery is evaluated separately. This is a sampled bound, not continuous health assurance. | [artifact](<events.json>), [artifact](<recovery/probe.json>), [artifact](<recovery/probe-window.json>), [artifact](<recovery/snapshot/snapshot.json>) |

## Evidence and interpretation

Injected-fault information is experiment ground truth. Interpretation is derived independently from these observations.

| Observation | Value | Primary evidence |
|---|---|---|
| baseline.backend_route_present | yes | [artifact](<baseline/snapshot/r1-routes.json>) |
| baseline.bgp_backend_prefix_present | yes | [artifact](<baseline/snapshot/r1-bgp-routes.json>) |
| baseline.bgp_peers_established | yes | [artifact](<baseline/snapshot/r1-bgp-summary.json>), [artifact](<baseline/snapshot/r2-bgp-summary.json>), [artifact](<baseline/snapshot/r3-bgp-summary.json>) |
| baseline.backend_prefix_denied | no | [artifact](<baseline/snapshot/r1-running-config.txt>), [artifact](<baseline/snapshot/r1-prefix-lists.txt>) |
| baseline.backend_prefix_policy_present | no | [artifact](<baseline/snapshot/r1-running-config.txt>), [artifact](<baseline/snapshot/r1-prefix-lists.txt>) |
| baseline.backend_prefix_policy | {"decision": null, "display_decision": null, "inbound_neighbors": [], "sources_consistent": true} | [artifact](<baseline/snapshot/r1-running-config.txt>), [artifact](<baseline/snapshot/r1-prefix-lists.txt>) |
| baseline.backend_listener_present | yes | [artifact](<baseline/snapshot/backend-sockets.txt>) |
| baseline.dns_ok | yes | [artifact](<baseline/snapshot/gateway-dns.json>) |
| baseline.primary_link_up | yes | [artifact](<baseline/snapshot/r1-links.json>) |
| baseline.netem_active | no | [artifact](<baseline/snapshot/gateway-netem.json>) |
| baseline.firewall_drop_active | no | [artifact](<baseline/snapshot/backend-firewall.json>) |
| baseline.firewall_drop_packets | 0 | [artifact](<baseline/snapshot/backend-firewall.json>) |
| baseline.backend_route_nexthop | 10.77.12.2 | [artifact](<baseline/snapshot/r1-routes.json>) |
| baseline.dns_result | {"address": "10.77.3.2", "name": "backend.lab", "ok": true, "rcode": 0} | not linked |
| baseline.gateway_metrics | {"accepted": 40, "accepted_definition": "all accepted TCP sockets including sockets immediately rejected at the connection limit", "active_connections": 0, "bytes_down": 10240, "bytes_up": 10240, "cpu_boundary": "cumulative CPU seconds for the entire process", "cpu_measurement_available": true, "cpu_system_seconds": 0.058907, "cpu_total_seconds": 0.117814, "cpu_user_seconds": 0.058907, "errors": {}, "errors_definition": "one terminal failure class per admitted session; connection-limit rejections are counted separately", "file_descriptors": 10, "gc_cycles": 1, "goroutines": 8, "heap_alloc_bytes": 633528, "heap_sys_bytes": 7667712, "log_dropped_total": 0, "log_policy": "64 queued records plus at most one sink write; overflow is dropped; one blocked sink goroutine may remain until release or process exit", "log_queue_capacity": 64, "log_queue_length": 0, "log_shutdown_timed_out": false, "log_sink_inflight": false, "log_write_errors_total": 0, "log_written_total": 40, "max_connections": 16, "rejected": 0, "rss_bytes": 8835072, "uptime_seconds": 4.837034157} | [artifact](<baseline/snapshot/gateway-metrics.json>) |
| baseline.probe | {"all_successful": true, "attempts": 40, "attempts_per_second": 20.46160561762988, "direct_probe": {"all_successful": true, "attempts": 10, "attempts_per_second": 11.049342646153923, "duration_seconds": 0.905031215, "errors": {}, "failures": 0, "latency_ms": {"p50": 0.976865, "p95": 1.546672, "p99": 1.546672}, "samples_truncated": false, "success_rate": 1.0, "successes": 10, "successful_bytes": 2560, "valid": true}, "duration_seconds": 1.954880802, "errors": {}, "failures": 0, "latency_ms": {"p50": 2.380886, "p95": 3.425803, "p99": 6.111971}, "samples_truncated": false, "success_rate": 1.0, "successes": 40, "successful_bytes": 10240, "valid": true} | [artifact](<baseline/probe.json>), [artifact](<baseline/direct-probe.json>) |
| baseline.direct_probe | {"all_successful": true, "attempts": 10, "attempts_per_second": 11.049342646153923, "duration_seconds": 0.905031215, "errors": {}, "failures": 0, "latency_ms": {"p50": 0.976865, "p95": 1.546672, "p99": 1.546672}, "samples_truncated": false, "success_rate": 1.0, "successes": 10, "successful_bytes": 2560, "valid": true} | [artifact](<baseline/direct-probe.json>) |
| fault.backend_route_present | yes | [artifact](<fault/snapshot/r1-routes.json>) |
| fault.bgp_backend_prefix_present | yes | [artifact](<fault/snapshot/r1-bgp-routes.json>) |
| fault.bgp_peers_established | yes | [artifact](<fault/snapshot/r1-bgp-summary.json>), [artifact](<fault/snapshot/r2-bgp-summary.json>), [artifact](<fault/snapshot/r3-bgp-summary.json>) |
| fault.backend_prefix_denied | no | [artifact](<fault/snapshot/r1-running-config.txt>), [artifact](<fault/snapshot/r1-prefix-lists.txt>) |
| fault.backend_prefix_policy_present | no | [artifact](<fault/snapshot/r1-running-config.txt>), [artifact](<fault/snapshot/r1-prefix-lists.txt>) |
| fault.backend_prefix_policy | {"decision": null, "display_decision": null, "inbound_neighbors": [], "sources_consistent": true} | [artifact](<fault/snapshot/r1-running-config.txt>), [artifact](<fault/snapshot/r1-prefix-lists.txt>) |
| fault.backend_listener_present | yes | [artifact](<fault/snapshot/backend-sockets.txt>) |
| fault.dns_ok | no | [artifact](<fault/snapshot/gateway-dns.json>) |
| fault.primary_link_up | yes | [artifact](<fault/snapshot/r1-links.json>) |
| fault.netem_active | no | [artifact](<fault/snapshot/gateway-netem.json>) |
| fault.firewall_drop_active | no | [artifact](<fault/snapshot/backend-firewall.json>) |
| fault.firewall_drop_packets | 0 | [artifact](<fault/snapshot/backend-firewall.json>) |
| fault.backend_route_nexthop | 10.77.12.2 | [artifact](<fault/snapshot/r1-routes.json>) |
| fault.dns_result | {"address": null, "name": "backend.lab", "ok": false, "rcode": 3} | not linked |
| fault.gateway_metrics | {"accepted": 80, "accepted_definition": "all accepted TCP sockets including sockets immediately rejected at the connection limit", "active_connections": 0, "bytes_down": 10240, "bytes_up": 10240, "cpu_boundary": "cumulative CPU seconds for the entire process", "cpu_measurement_available": true, "cpu_system_seconds": 0.088806, "cpu_total_seconds": 0.166956, "cpu_user_seconds": 0.07815, "errors": {"upstream_dns_error": 40}, "errors_definition": "one terminal failure class per admitted session; connection-limit rejections are counted separately", "file_descriptors": 10, "gc_cycles": 1, "goroutines": 8, "heap_alloc_bytes": 1099856, "heap_sys_bytes": 7667712, "log_dropped_total": 0, "log_policy": "64 queued records plus at most one sink write; overflow is dropped; one blocked sink goroutine may remain until release or process exit", "log_queue_capacity": 64, "log_queue_length": 0, "log_shutdown_timed_out": false, "log_sink_inflight": false, "log_write_errors_total": 0, "log_written_total": 80, "max_connections": 16, "rejected": 0, "rss_bytes": 9297920, "uptime_seconds": 9.220955861} | [artifact](<fault/snapshot/gateway-metrics.json>) |
| fault.probe | {"all_successful": false, "attempts": 40, "attempts_per_second": 20.4825365468389, "direct_probe": {"all_successful": true, "attempts": 10, "attempts_per_second": 11.09554951661534, "duration_seconds": 0.901262257, "errors": {}, "failures": 0, "latency_ms": {"p50": 0.807058, "p95": 1.105882, "p99": 1.105882}, "samples_truncated": false, "success_rate": 1.0, "successes": 10, "successful_bytes": 2560, "valid": true}, "duration_seconds": 1.9528831260000001, "errors": {"reset": 40}, "failures": 40, "latency_ms": {"p50": null, "p95": null, "p99": null}, "samples_truncated": false, "success_rate": 0.0, "successes": 0, "successful_bytes": 0, "valid": true} | [artifact](<fault/probe.json>), [artifact](<fault/direct-probe.json>) |
| fault.direct_probe | {"all_successful": true, "attempts": 10, "attempts_per_second": 11.09554951661534, "duration_seconds": 0.901262257, "errors": {}, "failures": 0, "latency_ms": {"p50": 0.807058, "p95": 1.105882, "p99": 1.105882}, "samples_truncated": false, "success_rate": 1.0, "successes": 10, "successful_bytes": 2560, "valid": true} | [artifact](<fault/direct-probe.json>) |
| recovery.backend_route_present | yes | [artifact](<recovery/snapshot/r1-routes.json>) |
| recovery.bgp_backend_prefix_present | yes | [artifact](<recovery/snapshot/r1-bgp-routes.json>) |
| recovery.bgp_peers_established | yes | [artifact](<recovery/snapshot/r1-bgp-summary.json>), [artifact](<recovery/snapshot/r2-bgp-summary.json>), [artifact](<recovery/snapshot/r3-bgp-summary.json>) |
| recovery.backend_prefix_denied | no | [artifact](<recovery/snapshot/r1-running-config.txt>), [artifact](<recovery/snapshot/r1-prefix-lists.txt>) |
| recovery.backend_prefix_policy_present | no | [artifact](<recovery/snapshot/r1-running-config.txt>), [artifact](<recovery/snapshot/r1-prefix-lists.txt>) |
| recovery.backend_prefix_policy | {"decision": null, "display_decision": null, "inbound_neighbors": [], "sources_consistent": true} | [artifact](<recovery/snapshot/r1-running-config.txt>), [artifact](<recovery/snapshot/r1-prefix-lists.txt>) |
| recovery.backend_listener_present | yes | [artifact](<recovery/snapshot/backend-sockets.txt>) |
| recovery.dns_ok | yes | [artifact](<recovery/snapshot/gateway-dns.json>) |
| recovery.primary_link_up | yes | [artifact](<recovery/snapshot/r1-links.json>) |
| recovery.netem_active | no | [artifact](<recovery/snapshot/gateway-netem.json>) |
| recovery.firewall_drop_active | no | [artifact](<recovery/snapshot/backend-firewall.json>) |
| recovery.firewall_drop_packets | 0 | [artifact](<recovery/snapshot/backend-firewall.json>) |
| recovery.backend_route_nexthop | 10.77.12.2 | [artifact](<recovery/snapshot/r1-routes.json>) |
| recovery.dns_result | {"address": "10.77.3.2", "name": "backend.lab", "ok": true, "rcode": 0} | not linked |
| recovery.gateway_metrics | {"accepted": 120, "accepted_definition": "all accepted TCP sockets including sockets immediately rejected at the connection limit", "active_connections": 0, "bytes_down": 20480, "bytes_up": 20480, "cpu_boundary": "cumulative CPU seconds for the entire process", "cpu_measurement_available": true, "cpu_system_seconds": 0.15013, "cpu_total_seconds": 0.26648, "cpu_user_seconds": 0.11635, "errors": {"upstream_dns_error": 40}, "errors_definition": "one terminal failure class per admitted session; connection-limit rejections are counted separately", "file_descriptors": 10, "gc_cycles": 2, "goroutines": 8, "heap_alloc_bytes": 1031560, "heap_sys_bytes": 7667712, "log_dropped_total": 0, "log_policy": "64 queued records plus at most one sink write; overflow is dropped; one blocked sink goroutine may remain until release or process exit", "log_queue_capacity": 64, "log_queue_length": 0, "log_shutdown_timed_out": false, "log_sink_inflight": false, "log_write_errors_total": 0, "log_written_total": 120, "max_connections": 16, "rejected": 0, "rss_bytes": 10182656, "uptime_seconds": 14.001892995} | [artifact](<recovery/snapshot/gateway-metrics.json>) |
| recovery.probe | {"all_successful": true, "attempts": 40, "attempts_per_second": 20.468978721087844, "direct_probe": {"all_successful": true, "attempts": 10, "attempts_per_second": 11.031006369675925, "duration_seconds": 0.906535602, "errors": {}, "failures": 0, "latency_ms": {"p50": 0.960237, "p95": 1.353313, "p99": 1.353313}, "samples_truncated": false, "success_rate": 1.0, "successes": 10, "successful_bytes": 2560, "valid": true}, "duration_seconds": 1.954176637, "errors": {}, "failures": 0, "latency_ms": {"p50": 2.561535, "p95": 3.407341, "p99": 5.236491}, "samples_truncated": false, "success_rate": 1.0, "successes": 40, "successful_bytes": 10240, "valid": true} | [artifact](<recovery/probe.json>), [artifact](<recovery/direct-probe.json>) |
| recovery.direct_probe | {"all_successful": true, "attempts": 10, "attempts_per_second": 11.031006369675925, "duration_seconds": 0.906535602, "errors": {}, "failures": 0, "latency_ms": {"p50": 0.960237, "p95": 1.353313, "p99": 1.353313}, "samples_truncated": false, "success_rate": 1.0, "successes": 10, "successful_bytes": 2560, "valid": true} | [artifact](<recovery/direct-probe.json>) |

Supporting observations: `baseline.dns_ok`, `fault.dns_ok`, `fault.probe`, `fault.direct_probe`.

## Restoration checks

| Check | Outcome |
|---|---|
| baseline_payload_transfer | verified |
| recovery_payload_transfer | verified |
| backend_route_present | verified |
| backend_listener_present | verified |
| dns_ok | verified |
| primary_link_up | verified |
| netem_active | verified |
| bgp_peers_established | verified |
| bgp_backend_prefix_present | verified |
| firewall_drop_active | verified |
| backend_prefix_denied | verified |
| backend_prefix_policy_present | verified |
| backend_route_nexthop | verified |

## Scenario acceptance

These checks are recomputed from the current observations and describe whether the intended experiment effect was observed; they are separate from the independently recomputed diagnosis.

| Check | Outcome |
|---|---|
| resolution_failed | verified |
| application_disrupted | verified |
| route_still_present | verified |
| direct_ip_control_succeeds | verified |

## Event timeline

| Sequence | Event | Local elapsed (s) | Wall time |
|---:|---|---:|---|
| 1 | startup-started | 1.248 | 2026-11-02T04:21:56.381524+00:00 |
| 2 | startup-finished | 4.922 | 2026-11-02T04:22:00.055231+00:00 |
| 3 | baseline-started | 4.938 | 2026-11-02T04:22:00.071474+00:00 |
| 4 | baseline-finished | 9.628 | 2026-11-02T04:22:02.431402+00:00 |
| 5 | fault-application-started | 9.641 | 2026-11-02T04:22:02.443848+00:00 |
| 6 | fault-applied | 9.655 | 2026-11-02T04:22:02.458368+00:00 |
| 7 | fault-started | 9.671 | 2026-11-02T04:22:02.474759+00:00 |
| 8 | fault-finished | 13.981 | 2026-11-02T04:22:06.784063+00:00 |
| 9 | restoration-started | 13.991 | 2026-11-02T04:22:06.794706+00:00 |
| 10 | restoration-finished | 14.107 | 2026-11-02T04:22:06.910573+00:00 |
| 11 | recovery-started | 14.119 | 2026-11-02T04:22:06.922492+00:00 |
| 12 | recovery-finished | 18.806 | 2026-11-02T04:22:11.609372+00:00 |
| 13 | cleanup-started | 18.817 | 2026-11-02T04:22:11.620057+00:00 |
| 14 | cleanup-finished | 20.121 | 2026-11-02T04:22:12.924799+00:00 |

## Injected change

```json
{
  "applied_at": "2026-11-02T04:22:02.456984+00:00",
  "apply_seconds": 0.00042989300004592224,
  "kind": "dns-failure",
  "status": "applied"
}
```

## Limitations

- baseline: fewer than 100 operations; tail percentiles have limited resolution.
- fault: fewer than 100 operations; tail percentiles have limited resolution.
- recovery: fewer than 100 operations; tail percentiles have limited resolution.
- route_convergence_seconds was not independently measured; phase snapshots do not establish this timing.
- Evidence is sampled within one host's local time context; cross-source timestamps do not imply perfect global synchronization.

Primary artifacts and checksums are listed in the experiment manifest. A configured route or disabled injector alone does not prove service recovery.
