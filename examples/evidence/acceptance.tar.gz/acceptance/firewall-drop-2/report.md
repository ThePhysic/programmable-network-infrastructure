# Network experiment report

Experiment: `cb777af2c5af404e9095e5023fe6ad44`  
Scenario: `firewall-drop`  
Started: 2026-11-02T04:21:33.790317+00:00

## Observed outcome

The lab firewall drop counter increased while application operations failed, supporting packet filtering as a contributing mechanism.

Evidence confidence: **supported**. Restoration: **verified**. Teardown verified: **yes**.

Experiment acceptance: **passed**. Scenario verification: **verified**.

## Workload and environment

```json
{
  "environment": {
    "cpu_model": "AMD Ryzen 9 7940HS w/ Radeon 780M Graphics",
    "doctor": {
      "binary": "/opt/netlab-public/programmable-network-infrastructure/bin/netlab-agent",
      "binary_exists": true,
      "environment": {
        "cpu_count": 16,
        "kernel": "6.18.54.1-microsoft-standard-WSL2",
        "platform": "Linux-6.18.54.1-microsoft-standard-WSL2-x86_64-with-glibc2.39",
        "python": "3.12.3"
      },
      "frr_vty_group_member": true,
      "linux": true,
      "ready": true,
      "root": true,
      "tools": {
        "bgpd": "/usr/lib/frr/bgpd",
        "ip": "/usr/sbin/ip",
        "nft": "/usr/sbin/nft",
        "python3": "/usr/bin/python3",
        "ss": "/usr/bin/ss",
        "tc": "/usr/sbin/tc",
        "tcpdump": "/usr/bin/tcpdump",
        "vtysh": "/usr/bin/vtysh",
        "zebra": "/usr/lib/frr/zebra"
      }
    },
    "frr_version": null,
    "go_binary_version": "/opt/netlab-public/programmable-network-infrastructure/bin/netlab-agent: go1.22.2",
    "iproute_version": "ip utility, iproute2-6.1.0, libbpf 1.3.0",
    "kernel": "6.18.54.1-microsoft-standard-WSL2",
    "logical_cpus": 16,
    "memory_total": "MemTotal:       15970204 kB",
    "netlab_version": "0.1.0",
    "nft_version": "nftables v1.0.9 (Old Doc Yak #3)",
    "platform": "Linux-6.18.54.1-microsoft-standard-WSL2-x86_64-with-glibc2.39",
    "python": "3.12.3"
  },
  "topology": {
    "alternate_path": [
      "gateway",
      "r1",
      "r3",
      "r2",
      "backend"
    ],
    "backend": "10.77.3.2:19090",
    "dns": "10.77.1.1:53",
    "gateway": "10.77.1.1:18080",
    "id": "six-node-bgp-diamond",
    "links": [
      {
        "left": "client",
        "left_address": "10.77.1.2/24",
        "left_interface": "eth0",
        "right": "gateway",
        "right_address": "10.77.1.1/24",
        "right_interface": "client0"
      },
      {
        "left": "gateway",
        "left_address": "10.77.2.2/24",
        "left_interface": "uplink0",
        "right": "r1",
        "right_address": "10.77.2.1/24",
        "right_interface": "gateway0"
      },
      {
        "left": "r1",
        "left_address": "10.77.12.1/24",
        "left_interface": "direct0",
        "right": "r2",
        "right_address": "10.77.12.2/24",
        "right_interface": "direct0"
      },
      {
        "left": "r1",
        "left_address": "10.77.13.1/24",
        "left_interface": "backup0",
        "right": "r3",
        "right_address": "10.77.13.3/24",
        "right_interface": "left0"
      },
      {
        "left": "r3",
        "left_address": "10.77.23.3/24",
        "left_interface": "right0",
        "right": "r2",
        "right_address": "10.77.23.2/24",
        "right_interface": "backup0"
      },
      {
        "left": "r2",
        "left_address": "10.77.3.1/24",
        "left_interface": "service0",
        "right": "backend",
        "right_address": "10.77.3.2/24",
        "right_interface": "eth0"
      }
    ],
    "namespace_prefix": "pnid-fa2106e5aa",
    "nodes": [
      "client",
      "gateway",
      "r1",
      "r2",
      "r3",
      "backend"
    ],
    "primary_path": [
      "gateway",
      "r1",
      "r2",
      "backend"
    ]
  },
  "workload": {
    "concurrency": 2,
    "connection_model": "one TCP connection per verified echo",
    "duration_seconds": 2.0,
    "payload_bytes": 256,
    "rate_per_second": 20.0
  }
}
```

## Measurements

Latency percentiles describe successful complete byte-verified operations. Failure counts have a separate denominator.

| Phase | Attempts | Successes | Errors | Success fraction | Duration (s) | Attempts/s | p50 (ms) | p95 (ms) | p99 (ms) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| baseline | 40 | 40 | 0 | 1.000 | 1.953 | 20.477 | 2.518 | 3.296 | 6.330 |
| fault | 6 | 0 | 6 | 0.000 | 2.456 | 2.443 | unmeasured | unmeasured | unmeasured |
| recovery | 40 | 40 | 0 | 1.000 | 1.953 | 20.479 | 2.556 | 3.837 | 4.400 |

### Recovery clocks

| Measurement | Seconds | Definition | Evidence |
|---|---:|---|---|
| fault_to_detection_seconds | 0.917 | Conservative upper bound from beginning fault application to first failed sampled echo completion; includes sampling gaps, timeout, and all parent/child launch/return overhead. | [artifact](<events.json>), [artifact](<fault/probe.json>), [artifact](<fault/probe-window.json>) |
| route_convergence_seconds | unmeasured | Routing change to a defined observed converged route state. | not linked |
| first_success_after_restoration_seconds | 0.245 | Conservative upper bound from restoration start to first successful sampled echo; includes restoration, sampling gaps, and all parent/child launch/return overhead. Earlier success may be unobserved. | [artifact](<events.json>), [artifact](<recovery/probe.json>), [artifact](<recovery/probe-window.json>) |
| stable_recovery_seconds | 2.197 | Completion of the error-free post-restoration probe window (at least one second); independent state recovery is evaluated separately. This is a sampled bound, not continuous health assurance. | [artifact](<events.json>), [artifact](<recovery/probe.json>), [artifact](<recovery/probe-window.json>), [artifact](<recovery/snapshot/snapshot.json>) |

## Evidence and interpretation

Injected-fault information is experiment ground truth. Interpretation is derived independently from these observations.

| Observation | Value | Primary evidence |
|---|---|---|
| baseline.backend_route_present | yes | [artifact](<baseline/snapshot/r1-routes.json>) |
| baseline.bgp_backend_prefix_present | yes | [artifact](<baseline/snapshot/r1-bgp-routes.json>) |
| baseline.bgp_peers_established | yes | [artifact](<baseline/snapshot/r1-bgp-summary.json>), [artifact](<baseline/snapshot/r2-bgp-summary.json>), [artifact](<baseline/snapshot/r3-bgp-summary.json>) |
| baseline.backend_prefix_denied | no | [artifact](<baseline/snapshot/r1-running-config.txt>), [artifact](<baseline/snapshot/r1-prefix-lists.txt>) |
| baseline.backend_prefix_policy_present | no | [artifact](<baseline/snapshot/r1-running-config.txt>), [artifact](<baseline/snapshot/r1-prefix-lists.txt>) |
| baseline.backend_prefix_policy | {"decision": null, "display_decision": null, "inbound_neighbors": [], "sources_consistent": true} | [artifact](<baseline/snapshot/r1-running-config.txt>), [artifact](<baseline/snapshot/r1-prefix-lists.txt>) |
| baseline.backend_listener_present | yes | [artifact](<baseline/snapshot/backend-sockets.txt>) |
| baseline.dns_ok | yes | [artifact](<baseline/snapshot/gateway-dns.json>) |
| baseline.primary_link_up | yes | [artifact](<baseline/snapshot/r1-links.json>) |
| baseline.netem_active | no | [artifact](<baseline/snapshot/gateway-netem.json>) |
| baseline.firewall_drop_active | no | [artifact](<baseline/snapshot/backend-firewall.json>) |
| baseline.firewall_drop_packets | 0 | [artifact](<baseline/snapshot/backend-firewall.json>) |
| baseline.backend_route_nexthop | 10.77.12.2 | [artifact](<baseline/snapshot/r1-routes.json>) |
| baseline.dns_result | {"address": "10.77.3.2", "name": "backend.lab", "ok": true, "rcode": 0} | not linked |
| baseline.gateway_metrics | {"accepted": 40, "accepted_definition": "all accepted TCP sockets including sockets immediately rejected at the connection limit", "active_connections": 0, "bytes_down": 10240, "bytes_up": 10240, "cpu_boundary": "cumulative CPU seconds for the entire process", "cpu_measurement_available": true, "cpu_system_seconds": 0.094286, "cpu_total_seconds": 0.122222, "cpu_user_seconds": 0.027936, "errors": {}, "errors_definition": "one terminal failure class per admitted session; connection-limit rejections are counted separately", "file_descriptors": 10, "gc_cycles": 1, "goroutines": 8, "heap_alloc_bytes": 749952, "heap_sys_bytes": 7634944, "log_dropped_total": 0, "log_policy": "64 queued records plus at most one sink write; overflow is dropped; one blocked sink goroutine may remain until release or process exit", "log_queue_capacity": 64, "log_queue_length": 0, "log_shutdown_timed_out": false, "log_sink_inflight": false, "log_write_errors_total": 0, "log_written_total": 40, "max_connections": 16, "rejected": 0, "rss_bytes": 8769536, "uptime_seconds": 3.904315251} | [artifact](<baseline/snapshot/gateway-metrics.json>) |
| baseline.probe | {"all_successful": true, "attempts": 40, "attempts_per_second": 20.477469564028542, "duration_seconds": 1.9533663510000001, "errors": {}, "failures": 0, "latency_ms": {"p50": 2.518121, "p95": 3.295916, "p99": 6.330163}, "samples_truncated": false, "success_rate": 1.0, "successes": 40, "successful_bytes": 10240, "valid": true} | [artifact](<baseline/probe.json>) |
| fault.backend_route_present | yes | [artifact](<fault/snapshot/r1-routes.json>) |
| fault.bgp_backend_prefix_present | yes | [artifact](<fault/snapshot/r1-bgp-routes.json>) |
| fault.bgp_peers_established | yes | [artifact](<fault/snapshot/r1-bgp-summary.json>), [artifact](<fault/snapshot/r2-bgp-summary.json>), [artifact](<fault/snapshot/r3-bgp-summary.json>) |
| fault.backend_prefix_denied | no | [artifact](<fault/snapshot/r1-running-config.txt>), [artifact](<fault/snapshot/r1-prefix-lists.txt>) |
| fault.backend_prefix_policy_present | no | [artifact](<fault/snapshot/r1-running-config.txt>), [artifact](<fault/snapshot/r1-prefix-lists.txt>) |
| fault.backend_prefix_policy | {"decision": null, "display_decision": null, "inbound_neighbors": [], "sources_consistent": true} | [artifact](<fault/snapshot/r1-running-config.txt>), [artifact](<fault/snapshot/r1-prefix-lists.txt>) |
| fault.backend_listener_present | yes | [artifact](<fault/snapshot/backend-sockets.txt>) |
| fault.dns_ok | yes | [artifact](<fault/snapshot/gateway-dns.json>) |
| fault.primary_link_up | yes | [artifact](<fault/snapshot/r1-links.json>) |
| fault.netem_active | no | [artifact](<fault/snapshot/gateway-netem.json>) |
| fault.firewall_drop_active | yes | [artifact](<fault/snapshot/backend-firewall.json>) |
| fault.firewall_drop_packets | 6 | [artifact](<fault/snapshot/backend-firewall.json>) |
| fault.backend_route_nexthop | 10.77.12.2 | [artifact](<fault/snapshot/r1-routes.json>) |
| fault.dns_result | {"address": "10.77.3.2", "name": "backend.lab", "ok": true, "rcode": 0} | not linked |
| fault.gateway_metrics | {"accepted": 46, "accepted_definition": "all accepted TCP sockets including sockets immediately rejected at the connection limit", "active_connections": 0, "bytes_down": 10240, "bytes_up": 10240, "cpu_boundary": "cumulative CPU seconds for the entire process", "cpu_measurement_available": true, "cpu_system_seconds": 0.10858, "cpu_total_seconds": 0.13819199999999998, "cpu_user_seconds": 0.029612, "errors": {"upstream_timeout": 6}, "errors_definition": "one terminal failure class per admitted session; connection-limit rejections are counted separately", "file_descriptors": 10, "gc_cycles": 1, "goroutines": 8, "heap_alloc_bytes": 869144, "heap_sys_bytes": 7602176, "log_dropped_total": 0, "log_policy": "64 queued records plus at most one sink write; overflow is dropped; one blocked sink goroutine may remain until release or process exit", "log_queue_capacity": 64, "log_queue_length": 0, "log_shutdown_timed_out": false, "log_sink_inflight": false, "log_write_errors_total": 0, "log_written_total": 46, "max_connections": 16, "rejected": 0, "rss_bytes": 8888320, "uptime_seconds": 8.097809413} | [artifact](<fault/snapshot/gateway-metrics.json>) |
| fault.probe | {"all_successful": false, "attempts": 6, "attempts_per_second": 2.442750984615823, "duration_seconds": 2.456247091, "errors": {"reset": 6}, "failures": 6, "latency_ms": {"p50": null, "p95": null, "p99": null}, "samples_truncated": false, "success_rate": 0.0, "successes": 0, "successful_bytes": 0, "valid": true} | [artifact](<fault/probe.json>) |
| recovery.backend_route_present | yes | [artifact](<recovery/snapshot/r1-routes.json>) |
| recovery.bgp_backend_prefix_present | yes | [artifact](<recovery/snapshot/r1-bgp-routes.json>) |
| recovery.bgp_peers_established | yes | [artifact](<recovery/snapshot/r1-bgp-summary.json>), [artifact](<recovery/snapshot/r2-bgp-summary.json>), [artifact](<recovery/snapshot/r3-bgp-summary.json>) |
| recovery.backend_prefix_denied | no | [artifact](<recovery/snapshot/r1-running-config.txt>), [artifact](<recovery/snapshot/r1-prefix-lists.txt>) |
| recovery.backend_prefix_policy_present | no | [artifact](<recovery/snapshot/r1-running-config.txt>), [artifact](<recovery/snapshot/r1-prefix-lists.txt>) |
| recovery.backend_prefix_policy | {"decision": null, "display_decision": null, "inbound_neighbors": [], "sources_consistent": true} | [artifact](<recovery/snapshot/r1-running-config.txt>), [artifact](<recovery/snapshot/r1-prefix-lists.txt>) |
| recovery.backend_listener_present | yes | [artifact](<recovery/snapshot/backend-sockets.txt>) |
| recovery.dns_ok | yes | [artifact](<recovery/snapshot/gateway-dns.json>) |
| recovery.primary_link_up | yes | [artifact](<recovery/snapshot/r1-links.json>) |
| recovery.netem_active | no | [artifact](<recovery/snapshot/gateway-netem.json>) |
| recovery.firewall_drop_active | no | [artifact](<recovery/snapshot/backend-firewall.json>) |
| recovery.firewall_drop_packets | 0 | [artifact](<recovery/snapshot/backend-firewall.json>) |
| recovery.backend_route_nexthop | 10.77.12.2 | [artifact](<recovery/snapshot/r1-routes.json>) |
| recovery.dns_result | {"address": "10.77.3.2", "name": "backend.lab", "ok": true, "rcode": 0} | not linked |
| recovery.gateway_metrics | {"accepted": 86, "accepted_definition": "all accepted TCP sockets including sockets immediately rejected at the connection limit", "active_connections": 0, "bytes_down": 20480, "bytes_up": 20480, "cpu_boundary": "cumulative CPU seconds for the entire process", "cpu_measurement_available": true, "cpu_system_seconds": 0.187119, "cpu_total_seconds": 0.2444, "cpu_user_seconds": 0.057281, "errors": {"upstream_timeout": 6}, "errors_definition": "one terminal failure class per admitted session; connection-limit rejections are counted separately", "file_descriptors": 10, "gc_cycles": 2, "goroutines": 8, "heap_alloc_bytes": 736352, "heap_sys_bytes": 7634944, "log_dropped_total": 0, "log_policy": "64 queued records plus at most one sink write; overflow is dropped; one blocked sink goroutine may remain until release or process exit", "log_queue_capacity": 64, "log_queue_length": 0, "log_shutdown_timed_out": false, "log_sink_inflight": false, "log_write_errors_total": 0, "log_written_total": 86, "max_connections": 16, "rejected": 0, "rss_bytes": 10551296, "uptime_seconds": 11.951345927} | [artifact](<recovery/snapshot/gateway-metrics.json>) |
| recovery.probe | {"all_successful": true, "attempts": 40, "attempts_per_second": 20.47890418137349, "duration_seconds": 1.953229511, "errors": {}, "failures": 0, "latency_ms": {"p50": 2.555912, "p95": 3.836605, "p99": 4.399857}, "samples_truncated": false, "success_rate": 1.0, "successes": 40, "successful_bytes": 10240, "valid": true} | [artifact](<recovery/probe.json>) |

Supporting observations: `baseline.firewall_drop_packets`, `fault.firewall_drop_packets`, `fault.probe`.

## Restoration checks

| Check | Outcome |
|---|---|
| baseline_payload_transfer | verified |
| recovery_payload_transfer | verified |
| backend_route_present | verified |
| backend_listener_present | verified |
| dns_ok | verified |
| primary_link_up | verified |
| netem_active | verified |
| bgp_peers_established | verified |
| bgp_backend_prefix_present | verified |
| firewall_drop_active | verified |
| backend_prefix_denied | verified |
| backend_prefix_policy_present | verified |
| backend_route_nexthop | verified |

## Scenario acceptance

These checks are recomputed from the current observations and describe whether the intended experiment effect was observed; they are separate from the independently recomputed diagnosis.

| Check | Outcome |
|---|---|
| route_still_present | verified |
| drop_counter_increased | verified |
| application_disrupted | verified |

## Event timeline

| Sequence | Event | Local elapsed (s) | Wall time |
|---:|---|---:|---|
| 1 | startup-started | 1.238 | 2026-11-02T04:21:32.553785+00:00 |
| 2 | startup-finished | 4.970 | 2026-11-02T04:21:36.285667+00:00 |
| 3 | baseline-started | 4.989 | 2026-11-02T04:21:36.304509+00:00 |
| 4 | baseline-finished | 8.713 | 2026-11-02T04:21:40.028927+00:00 |
| 5 | fault-application-started | 8.725 | 2026-11-02T04:21:40.041105+00:00 |
| 6 | fault-applied | 8.745 | 2026-11-02T04:21:40.060769+00:00 |
| 7 | fault-started | 8.762 | 2026-11-02T04:21:40.077845+00:00 |
| 8 | fault-finished | 12.896 | 2026-11-02T04:21:44.211652+00:00 |
| 9 | restoration-started | 12.906 | 2026-11-02T04:21:44.222416+00:00 |
| 10 | restoration-finished | 13.055 | 2026-11-02T04:21:44.370993+00:00 |
| 11 | recovery-started | 13.072 | 2026-11-02T04:21:44.387923+00:00 |
| 12 | recovery-finished | 16.757 | 2026-11-02T04:21:48.073001+00:00 |
| 13 | cleanup-started | 16.768 | 2026-11-02T04:21:48.083950+00:00 |
| 14 | cleanup-finished | 18.134 | 2026-11-02T04:21:49.450170+00:00 |

## Injected change

```json
{
  "applied_at": "2026-11-02T04:21:40.052067+00:00",
  "apply_seconds": 0.007833745999960229,
  "kind": "firewall-drop",
  "status": "applied"
}
```

## Limitations

- baseline: fewer than 100 operations; tail percentiles have limited resolution.
- fault: fewer than 100 operations; tail percentiles have limited resolution.
- recovery: fewer than 100 operations; tail percentiles have limited resolution.
- route_convergence_seconds was not independently measured; phase snapshots do not establish this timing.
- Evidence is sampled within one host's local time context; cross-source timestamps do not imply perfect global synchronization.

Primary artifacts and checksums are listed in the experiment manifest. A configured route or disabled injector alone does not prove service recovery.
