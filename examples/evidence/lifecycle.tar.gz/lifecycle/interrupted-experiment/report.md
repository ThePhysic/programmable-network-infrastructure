# Network experiment report

Experiment: `7e8c7d50f9354164a2746459e85c13cd`  
Scenario: `packet-loss`  
Started: 2026-11-02T04:18:30.278586+00:00

## Observed outcome

The available observations are insufficient to establish the application outcome.

Evidence confidence: **insufficient**. Restoration: **unverified**. Teardown verified: **yes**.

Experiment acceptance: **failed**. Scenario verification: **unverified**.

## Workload and environment

```json
{
  "environment": {
    "cpu_model": "AMD Ryzen 9 7940HS w/ Radeon 780M Graphics",
    "doctor": {
      "binary": "/opt/netlab-public/programmable-network-infrastructure/bin/netlab-agent",
      "binary_exists": true,
      "environment": {
        "cpu_count": 16,
        "kernel": "6.18.54.1-microsoft-standard-WSL2",
        "platform": "Linux-6.18.54.1-microsoft-standard-WSL2-x86_64-with-glibc2.39",
        "python": "3.12.3"
      },
      "frr_vty_group_member": true,
      "linux": true,
      "ready": true,
      "root": true,
      "tools": {
        "bgpd": "/usr/lib/frr/bgpd",
        "ip": "/usr/sbin/ip",
        "nft": "/usr/sbin/nft",
        "python3": "/usr/bin/python3",
        "ss": "/usr/bin/ss",
        "tc": "/usr/sbin/tc",
        "tcpdump": "/usr/bin/tcpdump",
        "vtysh": "/usr/bin/vtysh",
        "zebra": "/usr/lib/frr/zebra"
      }
    },
    "frr_version": null,
    "go_binary_version": "/opt/netlab-public/programmable-network-infrastructure/bin/netlab-agent: go1.22.2",
    "iproute_version": "ip utility, iproute2-6.1.0, libbpf 1.3.0",
    "kernel": "6.18.54.1-microsoft-standard-WSL2",
    "logical_cpus": 16,
    "memory_total": "MemTotal:       15970204 kB",
    "netlab_version": "0.1.0",
    "nft_version": "nftables v1.0.9 (Old Doc Yak #3)",
    "platform": "Linux-6.18.54.1-microsoft-standard-WSL2-x86_64-with-glibc2.39",
    "python": "3.12.3"
  },
  "topology": {
    "alternate_path": [
      "gateway",
      "r1",
      "r3",
      "r2",
      "backend"
    ],
    "backend": "10.77.3.2:19090",
    "dns": "10.77.1.1:53",
    "gateway": "10.77.1.1:18080",
    "id": "six-node-bgp-diamond",
    "links": [
      {
        "left": "client",
        "left_address": "10.77.1.2/24",
        "left_interface": "eth0",
        "right": "gateway",
        "right_address": "10.77.1.1/24",
        "right_interface": "client0"
      },
      {
        "left": "gateway",
        "left_address": "10.77.2.2/24",
        "left_interface": "uplink0",
        "right": "r1",
        "right_address": "10.77.2.1/24",
        "right_interface": "gateway0"
      },
      {
        "left": "r1",
        "left_address": "10.77.12.1/24",
        "left_interface": "direct0",
        "right": "r2",
        "right_address": "10.77.12.2/24",
        "right_interface": "direct0"
      },
      {
        "left": "r1",
        "left_address": "10.77.13.1/24",
        "left_interface": "backup0",
        "right": "r3",
        "right_address": "10.77.13.3/24",
        "right_interface": "left0"
      },
      {
        "left": "r3",
        "left_address": "10.77.23.3/24",
        "left_interface": "right0",
        "right": "r2",
        "right_address": "10.77.23.2/24",
        "right_interface": "backup0"
      },
      {
        "left": "r2",
        "left_address": "10.77.3.1/24",
        "left_interface": "service0",
        "right": "backend",
        "right_address": "10.77.3.2/24",
        "right_interface": "eth0"
      }
    ],
    "namespace_prefix": "pnid-146c371f32",
    "nodes": [
      "client",
      "gateway",
      "r1",
      "r2",
      "r3",
      "backend"
    ],
    "primary_path": [
      "gateway",
      "r1",
      "r2",
      "backend"
    ]
  },
  "workload": {
    "concurrency": 2,
    "connection_model": "one TCP connection per verified echo",
    "duration_seconds": 30.0,
    "payload_bytes": 256,
    "rate_per_second": 20.0
  }
}
```

## Measurements

Latency percentiles describe successful complete byte-verified operations. Failure counts have a separate denominator.

| Phase | Attempts | Successes | Errors | Success fraction | Duration (s) | Attempts/s | p50 (ms) | p95 (ms) | p99 (ms) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| baseline | unmeasured | unmeasured | unmeasured | unmeasured | unmeasured | unmeasured | unmeasured | unmeasured | unmeasured |
| fault | unmeasured | unmeasured | unmeasured | unmeasured | unmeasured | unmeasured | unmeasured | unmeasured | unmeasured |
| recovery | unmeasured | unmeasured | unmeasured | unmeasured | unmeasured | unmeasured | unmeasured | unmeasured | unmeasured |

### Recovery clocks

| Measurement | Seconds | Definition | Evidence |
|---|---:|---|---|
| fault_to_detection_seconds | unmeasured | Fault application to the first independently observed failed operation. | not linked |
| route_convergence_seconds | unmeasured | Routing change to a defined observed converged route state. | not linked |
| first_success_after_restoration_seconds | unmeasured | Restoration start to the first successful application operation. | not linked |
| stable_recovery_seconds | unmeasured | Restoration start to a stated sustained healthy observation window. | not linked |

## Evidence and interpretation

Injected-fault information is experiment ground truth. Interpretation is derived independently from these observations.

| Observation | Value | Primary evidence |
|---|---|---|
| baseline.probe | {"all_successful": false, "attempts": null, "attempts_per_second": null, "duration_seconds": null, "errors": {}, "failures": null, "latency_ms": {"p50": null, "p95": null, "p99": null}, "samples_truncated": false, "success_rate": null, "successes": null, "successful_bytes": null, "valid": false} | not linked |
| fault.probe | {"all_successful": false, "attempts": null, "attempts_per_second": null, "duration_seconds": null, "errors": {}, "failures": null, "latency_ms": {"p50": null, "p95": null, "p99": null}, "samples_truncated": false, "success_rate": null, "successes": null, "successful_bytes": null, "valid": false} | not linked |
| recovery.probe | {"all_successful": false, "attempts": null, "attempts_per_second": null, "duration_seconds": null, "errors": {}, "failures": null, "latency_ms": {"p50": null, "p95": null, "p99": null}, "samples_truncated": false, "success_rate": null, "successes": null, "successful_bytes": null, "valid": false} | not linked |

Supporting observations: `fault.probe`.

## Restoration checks

| Check | Outcome |
|---|---|
| baseline_payload_transfer | unverified |
| recovery_payload_transfer | unverified |
| backend_route_present | unverified |
| backend_listener_present | unverified |
| dns_ok | unverified |
| primary_link_up | unverified |
| netem_active | unverified |
| bgp_peers_established | unverified |
| bgp_backend_prefix_present | unverified |
| firewall_drop_active | unverified |
| backend_prefix_denied | unverified |
| backend_prefix_policy_present | unverified |

## Scenario acceptance

These checks are recomputed from the current observations and describe whether the intended experiment effect was observed; they are separate from the independently recomputed diagnosis.

| Check | Outcome |
|---|---|
| impairment_observed | failed |
| application_effect_observed | failed |

Recorded execution failure:

```json
{
  "message": "",
  "type": "KeyboardInterrupt"
}
```

## Event timeline

| Sequence | Event | Local elapsed (s) | Wall time |
|---:|---|---:|---|
| 1 | startup-started | 1.282 | 2026-11-02T04:18:31.560481+00:00 |
| 2 | startup-finished | 5.121 | 2026-11-02T04:18:33.074813+00:00 |
| 3 | baseline-started | 5.135 | 2026-11-02T04:18:33.088687+00:00 |
| 4 | experiment-failed | 5.606 | 2026-11-02T04:18:33.559995+00:00 |
| 5 | cleanup-started | 5.617 | 2026-11-02T04:18:33.571375+00:00 |
| 6 | cleanup-finished | 6.835 | 2026-11-02T04:18:34.788631+00:00 |

## Injected change

```json
{}
```

## Limitations

- baseline: missing or inconsistent probe operation counts.
- fault: missing or inconsistent probe operation counts.
- recovery: missing or inconsistent probe operation counts.
- Recovery is unverified for baseline_payload_transfer.
- Recovery is unverified for recovery_payload_transfer.
- Recovery is unverified for backend_route_present.
- Recovery is unverified for backend_listener_present.
- Recovery is unverified for dns_ok.
- Recovery is unverified for primary_link_up.
- Recovery is unverified for netem_active.
- Recovery is unverified for bgp_peers_established.
- Recovery is unverified for bgp_backend_prefix_present.
- Recovery is unverified for firewall_drop_active.
- Recovery is unverified for backend_prefix_denied.
- Recovery is unverified for backend_prefix_policy_present.
- fault_to_detection_seconds was not independently measured; phase snapshots do not establish this timing.
- route_convergence_seconds was not independently measured; phase snapshots do not establish this timing.
- first_success_after_restoration_seconds was not independently measured; phase snapshots do not establish this timing.
- stable_recovery_seconds was not independently measured; phase snapshots do not establish this timing.
- Evidence is sampled within one host's local time context; cross-source timestamps do not imply perfect global synchronization.

Primary artifacts and checksums are listed in the experiment manifest. A configured route or disabled injector alone does not prove service recovery.
